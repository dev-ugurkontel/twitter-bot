module.exports = {
  consumer_key          : 'whopcod',  
  consumer_secret       : 'whopcod',
  access_token          : 'whopcod',  
  access_token_secret   : 'whopcod'
}